public class Melee {
    /*private int health;
    private int x, y; // Character's position

    public Melee(int health, int x, int y) {
        this.health = health;
        this.x = x;
        this.y = y;
    }

    public void shoot(Enemy enemy) {
        if (isEnemyInRange(enemy)) {
           // enemy.reduceHealth();
            System.out.println("Shot fired!");
        } else {
            System.out.println("Enemy out of range!");
        }
    }

    private boolean isEnemyInRange(Enemy enemy) {
        // Check if enemy is in range
        return Math.abs(enemy.getX() - x) + Math.abs(enemy.getY() - y) <= 5; // Example range
}
   */ 
  }

