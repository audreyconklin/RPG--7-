import javax.swing.ImageIcon;

public class Ranged extends Weapons {
    public Ranged(){
     super();
    }

    public Ranged(int xV, int yV, int width, int height, int d, int dur, int dp, ImageIcon p) {
        super(xV,yV,width, height, d,dur,dp,p);
    }


}